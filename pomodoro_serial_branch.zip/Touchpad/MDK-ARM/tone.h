#ifndef __TONE
#define __TONE

#include "stm32f1xx_hal.h"

//put tone function here


#endif
