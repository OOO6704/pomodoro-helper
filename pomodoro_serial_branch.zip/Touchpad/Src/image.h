//Image.h
#ifndef __IMAGE
#define __IMAGE

extern const char pomodoro[3200];

#endif
